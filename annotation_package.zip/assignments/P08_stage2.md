# Stage 2 task sheet for P08 (Sun Nov 1 - Sat Nov 7; due Sat Nov 7, 23:59)

Download the current `annotation_package.zip`: your files are in its `stage2/` folder. About **156 min**.

**Rules (all parts)**
- Work **alone**. Do not discuss any item with anyone until all stages are finished (Nov 9).
- **No AI tools, chatbots, translation tools or search engines** for any part. Your own judgment is the data.
- Use only the files in `annotation_package/`. Do not open the project repository or any other files.
- Use the same ID, **P08**, everywhere. Do the steps **in the order listed**: the order matters for the study.
- Each tool saves progress in your browser, but **click "Download CSV" at the end of every step** and keep the files.
- If something is unclear, write a short note (the tools have note boxes) and carry on; don't ask other annotators.

## Steps (in this order)

- [ ] **1. Part 8: Check 30 sentence pairs, file 1 of 3** (about 22 min)  
  Open `check_pairs.html`, click **Check file**, choose `stage2/P08_check_1.json`, enter `P08`. README: Part 8. Return: `check_pairs_P08_check_1_P08.csv`.
- [ ] **2. Part 8: Check 30 sentence pairs, file 2 of 3** (about 22 min)  
  Open `check_pairs.html`, click **Check file**, choose `stage2/P08_check_2.json`, enter `P08`. README: Part 8. Return: `check_pairs_P08_check_2_P08.csv`.
- [ ] **3. Part 8: Check 30 sentence pairs, file 3 of 3** (about 22 min)  
  Open `check_pairs.html`, click **Check file**, choose `stage2/P08_check_3.json`, enter `P08`. README: Part 8. Return: `check_pairs_P08_check_3_P08.csv`.
- [ ] **4. Read CODEBOOK.md once (definitions used by annotate.html)** (about 10 min)  
  About 10 minutes, once. Short definitions also stay on screen in the tool.
- [ ] **5. Part 12: Sentence labels on new outputs (about 150 sentences)** (about 80 min)  
  Open `annotate.html`, enter `P08`, load `stage2/part12_gold_elic.json` (arrives in a later zip update: the coordinator will tell you; do steps 1-4 first), do the 5 practice items, then every item. README: Part 10 (this part is the same task on a new file). Return: `labels_gold_elic_P08.csv`.

Return: email every CSV above to the coordinator by Sat Nov 7, 23:59 (subject `AAC annotation P08 stage 2`), with the time you spent and any notes.

Thank you! Your work is anonymous: only your ID is recorded. You can stop at any time.
